#include <gb/gb.h>
#include <stdio.h>

void main()
{
	printf("Hello world!\n");
	printf("\nPress Start t");
	waitpad(J_START);
}